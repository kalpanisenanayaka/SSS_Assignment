# -SynchronizerTokens-php
 Synchronizer Token Patterns Example with PHP
